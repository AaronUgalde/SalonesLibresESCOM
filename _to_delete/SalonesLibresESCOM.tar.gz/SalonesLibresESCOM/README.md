# Salones libres · ESCOM

App Android (Kotlin + Jetpack Compose) que muestra en un croquis de la ESCOM qué salones están libres a cualquier día y hora.

## Abrir y correr
1. Android Studio → **Open** → esta carpeta.
2. Deja que sincronice Gradle (usa las mismas versiones que MetroAR-CDMX: AGP 9.4.1, Kotlin 2.4.21, Compose BOM 2026.09.00).
3. Corre la configuración `app` en un emulador o tu teléfono.
4. Pruebas de la lógica: `./gradlew :app:testDebugUnitTest`.

## Estructura
- `data/Horarios.kt`: modelo `Clase` y lectura de `assets/data.json`.
- `domain/Ocupacion.kt`: estado de cada salón a una hora (libre, grupo en lab, con clase, probable, sin datos).
- `domain/Croquis.kt`: geometría del croquis por piso (supuesto 4-3-4-3 por bloque, numeración sur→norte).
- `ui/`: pantalla principal, mapa dibujado con `Canvas` y hoja de detalle por salón.

## Colores
| Color | Significado |
|---|---|
| Verde | Libre |
| Verde azulado | El grupo debería estar en laboratorio (sesión "L"); puede regresar |
| Rojo | Con clase (SAES o foto) |
| Ámbar | Con clase, pero el salón del grupo es estimado (Distribución 26-1) |
| Gris | El salón no aparece en ningún horario |

## Actualizar los datos
Los datos viven en `app/src/main/assets/data.json` y se generan con `datos/build.py`:

```
cd datos
python3 build.py
```

Fuentes, de mayor a menor prioridad:
1. **Fotos** de las hojas pegadas afuera de los salones → `datos/fotos.py` (`FOTOS`, `LABS`, `EXTRAS`).
2. **SAES** (Horarios de clase, todas las carreras/turnos/semestres) → `datos/horarios_saes_2026-11-13.json`.
3. **Distribución de salones 26-1** para los grupos sin salón en el SAES → `datos/mapeo_26_1.py` (se marcan como estimados).

Formato de cada clase en `data.json`: `[salon, dia(0=Lun), inicio_min, fin_min, grupo, materia, profesor, estimado(0/1/2), laboratorio(0/1)]`.
