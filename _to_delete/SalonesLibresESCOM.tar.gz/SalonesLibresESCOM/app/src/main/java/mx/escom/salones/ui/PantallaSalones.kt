package mx.escom.salones.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import mx.escom.salones.data.Clase
import mx.escom.salones.domain.Croquis
import mx.escom.salones.domain.Estado
import mx.escom.salones.domain.formatoHora
import kotlin.math.roundToInt

private val DIAS = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaSalones(vm: SalonesViewModel = viewModel()) {
    val ocupacion = vm.ocupacion
    val dia = vm.dia
    val minuto = vm.minuto
    val resumen = remember(dia, minuto) { ocupacion.resumen(dia, minuto) }
    val sinDatos = remember { Croquis.todosLosSalones.count { it !in ocupacion.salonesConDatos } }

    Scaffold(topBar = { TopAppBar(title = { Text("Salones libres · ESCOM") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Controles(
                    dia = dia,
                    minuto = minuto,
                    onDia = { vm.dia = it },
                    onMinuto = { vm.minuto = it },
                    onMover = vm::moverMinutos,
                    onAhora = vm::irAAhora,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Contador(resumen.libres.size, "libres", Colores.libre, Modifier.weight(1f))
                    Contador(resumen.enLab.size, "grupo en lab", Colores.enLab, Modifier.weight(1f))
                    Contador(resumen.ocupados, "con clase", Colores.ocupado, Modifier.weight(1f))
                    Contador(resumen.probables, "probable", Colores.probable, Modifier.weight(1f))
                    Contador(sinDatos, "sin datos", Colores.sinDatosTexto, Modifier.weight(1f))
                }
            }
            item {
                Card {
                    Column(Modifier.padding(8.dp)) {
                        PrimaryTabRow(selectedTabIndex = vm.piso) {
                            Croquis.PISOS.forEachIndexed { i, nombre ->
                                Tab(selected = vm.piso == i, onClick = { vm.piso = i }, text = { Text(nombre) })
                            }
                        }
                        Spacer(Modifier.size(8.dp))
                        MapaCroquis(
                            piso = vm.piso,
                            estadoDe = { ocupacion.estado(it, dia, minuto) },
                            seleccionado = vm.seleccionado,
                            onSalon = vm::seleccionar,
                        )
                        Leyenda()
                        Text(
                            "Posiciones aproximadas (bloques 4-3-4-3, numeración sur→norte).",
                            style = MaterialTheme.typography.bodySmall,
                            color = Colores.probable,
                        )
                    }
                }
            }
            item {
                Column {
                    Text("Libres a esta hora", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.size(6.dp))
                    ListaLibres(resumen.libres, resumen.enLab, onSalon = vm::seleccionar)
                }
            }
            item {
                Text(
                    "Datos: ${vm.horarios.fuente} (${vm.horarios.capturado.take(10)}). " +
                        "\"Libre\" solo significa que no hay clase registrada; puede haber asesorías o cambios.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Colores.tenue,
                )
            }
        }
    }

    vm.seleccionado?.let { salon ->
        ModalBottomSheet(onDismissRequest = { vm.seleccionado = null }) {
            DetalleSalon(
                salon = salon,
                dia = dia,
                minuto = minuto,
                estado = ocupacion.estado(salon, dia, minuto),
                clases = ocupacion.clasesDelDia(salon, dia),
            )
        }
    }
}

@Composable
private fun Controles(
    dia: Int,
    minuto: Int,
    onDia: (Int) -> Unit,
    onMinuto: (Int) -> Unit,
    onMover: (Int) -> Unit,
    onAhora: () -> Unit,
) {
    Card {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                DIAS.forEachIndexed { i, nombre ->
                    SegmentedButton(
                        selected = dia == i,
                        onClick = { onDia(i) },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = DIAS.size),
                        icon = {},
                    ) { Text(nombre, fontSize = 13.sp, maxLines = 1) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(formatoHora(minuto), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = { onMover(-15) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("−15") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { onMover(15) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("+15") }
                Spacer(Modifier.width(6.dp))
                Button(onClick = onAhora) { Text("Ahora") }
            }
            Slider(
                value = minuto.toFloat(),
                onValueChange = { onMinuto(((it / 15f).roundToInt() * 15)) },
                valueRange = 420f..1290f,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("7:00", "10:30", "13:30", "16:30", "20:00", "21:30").forEach {
                    Text(it, style = MaterialTheme.typography.labelSmall, color = Colores.tenue)
                }
            }
        }
    }
}

@Composable
private fun Contador(valor: Int, etiqueta: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$valor", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(etiqueta, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Leyenda() {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.padding(vertical = 6.dp),
    ) {
        listOf(
            Colores.libre to "Libre",
            Colores.enLab to "Grupo en lab (puede regresar)",
            Colores.ocupado to "Con clase",
            Colores.probable to "Probable (salón estimado)",
            Colores.sinDatos to "Sin datos",
        ).forEach { (color, texto) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
                Spacer(Modifier.width(4.dp))
                Text(texto, style = MaterialTheme.typography.labelSmall, color = Colores.tenue)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ListaLibres(
    libres: List<Pair<String, Int?>>,
    enLab: List<Pair<String, Int?>>,
    onSalon: (String) -> Unit,
) {
    if (libres.isEmpty() && enLab.isEmpty()) {
        Text("Ninguno.", color = Colores.tenue)
        return
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((salon, hasta) in libres) ChipSalon(salon, hasta, false, onSalon)
        for ((salon, hasta) in enLab) ChipSalon(salon, hasta, true, onSalon)
    }
}

@Composable
private fun ChipSalon(salon: String, hasta: Int?, enLab: Boolean, onSalon: (String) -> Unit) {
    val detalle = (if (enLab) "grupo en lab · " else "") + (hasta?.let { "hasta ${formatoHora(it)}" } ?: "todo el día")
    SuggestionChip(
        onClick = { onSalon(salon) },
        label = { Text("$salon  $detalle", fontSize = 13.sp) },
        colors = SuggestionChipDefaults.suggestionChipColors(
            containerColor = (if (enLab) Colores.enLab else Colores.libre).copy(alpha = 0.15f),
        ),
    )
}

@Composable
private fun DetalleSalon(salon: String, dia: Int, minuto: Int, estado: Estado, clases: List<Clase>) {
    val resumen = when (estado) {
        is Estado.Libre -> estado.hasta?.let { "Libre hasta las ${formatoHora(it)}" } ?: "Libre el resto del día"
        is Estado.GrupoEnLab ->
            "El ${estado.clase.grupo} debería estar en laboratorio hasta las ${formatoHora(estado.clase.fin)} " +
                "(a veces se quedan en el salón)"
        is Estado.Ocupado -> "Con clase: ${estado.clase.grupo}"
        is Estado.Probable -> "Probablemente con clase: ${estado.clase.grupo} (salón estimado)"
        Estado.SinDatos -> "No aparece en ningún horario"
    }
    Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
        Text("Salón $salon", style = MaterialTheme.typography.headlineSmall)
        Text("${DIAS[dia]} ${formatoHora(minuto)} · $resumen", color = Colores.de(estado).takeIf { estado != Estado.SinDatos } ?: Colores.tenue)
        Spacer(Modifier.size(12.dp))
        if (clases.isEmpty()) {
            Text("Sin clases registradas este día.", color = Colores.tenue)
        } else {
            LazyColumn {
                items(clases) { c ->
                    val ahora = !c.laboratorio && c.estimado < 2 && c.ini <= minuto && minuto < c.fin
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(if (ahora) Colores.ocupado.copy(alpha = 0.12f) else Color.Transparent)
                            .padding(vertical = 8.dp),
                    ) {
                        Text(
                            "${formatoHora(c.ini)}–${formatoHora(c.fin)}",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(96.dp),
                        )
                        Column {
                            Text("${c.grupo} · ${c.materia}")
                            if (c.profesor.isNotBlank()) {
                                Text(c.profesor, style = MaterialTheme.typography.bodySmall, color = Colores.tenue)
                            }
                            val notas = buildList {
                                if (c.laboratorio) add("en laboratorio: el salón queda libre")
                                if (c.estimado == 1) add("salón estimado")
                                if (c.estimado == 2) add("estimado que choca con un dato confirmado: se ignora")
                            }
                            if (notas.isNotEmpty()) {
                                Text(notas.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = Colores.probable)
                            }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
